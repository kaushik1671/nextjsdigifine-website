const customDigifineFeatures = [
    "✅ 100% Placement Guarantee with Industry Residency Program at top companies & agencies after only 6 months",
    "✅ Guaranteed extensions and salary hikes",
    "✅ In-hand Offer Letter on the 1st day of admission",
    "✅ International Visit to Dubai for Luxury Brand Management",
    "✅ Training on Unique modules like Experiential Marketing, Television Planning (BARC), Programmatic Media Buying, OTT Advertising, Data Analytics, Strategic Management, Website Development, E-Commerce & Brand Management",
    "✅ Google certifications & ISO certifications that are globally recognized for key digital marketing modules",
    "✅ Highly experienced in-house trainers",
    "✅ International Certification from the IBM Institute in Berlin, Germany",
    "✅ Guest lecturers with years of industry expertise",
    "✅ Practical Training with Live Projects, Case Studies, and Regular Assignments",
    "✅ Post-Course Support for students even after course completion",
    "✅ 300+hours of Intense Daily Classroom Training",

  ];

export default customDigifineFeatures
const steps = [
    {
      title: 'Get Trained',
      description: 'Get digital marketing classroom training from expert faculty through practical training and industry exposure!',
    },
    {
      title: 'Interviews',
      description: 'Crack mock interviews and get placed with impressive packages at top digital marketing agencies in India!',
    },
    {
      title: 'Industry Residency Program',
      description: 'Apply and hone your skills while getting incredible salary hikes with these exclusive extension programs!',
    },
  ]

export default steps;
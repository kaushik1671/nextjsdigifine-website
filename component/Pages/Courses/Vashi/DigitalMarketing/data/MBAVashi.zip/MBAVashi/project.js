const projects = [
    {
        imageSrc: "/images/Icons/job.png",
        title: "SEO",
        description:
          "Learn on-page, off-page and technical SEO by deriving lessons from case studies of various brands like Tata Motors and rank any website with just a few steps!",
        skills: ["SEO"],
        additionalSkillsCount: 7,
  
        // MODAL CONTENT
        modalIcon: "/images/Icons/award.webp",
        modalTitle: "Additional Skills (7)",
        modalSummary:
          "These include feature engineering, cost-benefit analysis, fraud detection pipelines, model evaluation metrics, and advanced ML techniques used to detect fraudulent transactions.",
      },
      {
        imageSrc: "/images/Icons/job.png",
        title: "Media Planning",
        description:
          " Apply concepts of strategic management in real-time by learning how to build a media plan for brands like Citron with complete guidance from trainers.",
        skills: ["Data Understanding"],
        additionalSkillsCount: 5,
  
        modalIcon: "/images/Icons/award.webp",
        modalTitle: "Additional Skills (5)",
        modalSummary:
          "Skills include Pareto analysis, market basket analysis, pricing insights, customer segmentation, and retail performance visualization.",
      },
      {
        imageSrc: "/images/Icons/job.png",
        title: "Programmatic Advertising",
        description:
          " Guest trainers with years of industry experience in the programmatic media field will train you on projects for brands like Cadbury, Netflix, etc.",
        skills: ["Data Understanding"],
        additionalSkillsCount: 4,
  
        modalIcon: "/images/Icons/award.webp",
        modalTitle: "Additional Skills (4)",
        modalSummary:
          "Includes revenue forecasting, churn analysis, marketing mix modeling, and dashboard-building for ecommerce KPIs.",
      },
      {
        imageSrc: "/images/Icons/job.png",
        title: "Influencer Marketing",
        description:
          " Acquire insights from Foxtail brand’s case study on influencer marketing and apply them to your own ideation and campaign creation!",
        skills: ["Data Understanding"],
        additionalSkillsCount: 5,
  
        modalIcon: "/images/Icons/award.webp",
        modalTitle: "Additional Skills (5)",
        modalSummary:
          "Covers NLP preprocessing, sentiment scoring, recommendation algorithms, text classification, and model deployment.",
      },{
        imageSrc: "/images/Icons/job.png",
        title: "Online Reputation Management",
        description:
          "Build trust and credibility while managing customer feedback through an ORM case study of Reliance Jio.",
        skills: ["Data Understanding"],
        additionalSkillsCount: 5,
  
        modalIcon: "/images/Icons/award.webp",
        modalTitle: "Additional Skills (5)",
        modalSummary:
          "Covers NLP preprocessing, sentiment scoring, recommendation algorithms, text classification, and model deployment.",
      },
]

export default projects